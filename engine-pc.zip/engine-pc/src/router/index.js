import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/page/Home'

import SystemInfo from '@/page/systemInfo/systemInfo'
import SystemRoleInfo from '@/page/systemInfo/systemRoleInfo'
import SystemUserInfo from '@/page/systemInfo/SystemUserInfo'

import BaseUserInfo from '@/page/baseInfo/userInfo'
import CustomerInfo from '@/page/baseInfo/CustomerInfo'
import GoodsInfo from '@/page/baseInfo/GoodsInfo'
import OrderInfo from '@/page/baseInfo/OrderInfo'

import Default from '@/page/index/default'
import Adjpwd from '@/page/user/adjpwd'
import UserInfo from '@/page/user/userInfo'

import STORE from '../api/local_store';
// 懒加载方式，当路由被访问的时候才加载对应组件
const Login = resolve => require(['@/page/index/Login'], resolve)

Vue.use(Router)

let router = new Router({
// mode: 'history',
  routes: [
    {path: '/login', name: '登录', component: Login},
    {path: '/baseInfo/orderInfo', component: OrderInfo, menuShow: true},
    {
      path: '/',
      name: 'home',
      component: Home,
      redirect: '/default',
      leaf: true, // 只有一个节点
      menuShow: true,
      iconCls: 'iconfont icon-home', // 图标样式class
      children: [
        {path: '/default', component: Default, menuShow: true},

        {path: '/baseInfo/user', component: BaseUserInfo, menuShow: true},
        {path: '/baseInfo/customer', component: CustomerInfo, menuShow: true},
        {path: '/baseInfo/goods', component: GoodsInfo, menuShow: true},

        {path: '/system/systemInfo', component: SystemInfo, menuShow: true},
        {path: '/system/systemRoleInfo', component: SystemRoleInfo, menuShow: true},
        {path: '/system/systemUserInfo', component: SystemUserInfo, menuShow: true},
        
        {path: '/index/userInfo', component: UserInfo, menuShow: true},
        {path: '/index/adjPwd', component: Adjpwd, menuShow: true}
      ]
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (to.path.startsWith('/login')) {
    STORE.remove()
    next()
  } else {
    let user = STORE.getUser()
    if(user == null) {
      next({path: '/login'})
    } else {
      next()
    }
  }
})

export default router
