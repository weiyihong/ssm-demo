<template>
  <div class="app-box-container">
  sdfsd
  </div>
</template>
<script>
export default {
  name:'AppConfirm',
  props:{
    title:{
      default(){
        return "确认"
      }
    },
    content:{
      default(){
        return '确认保存？'
      }
    }
  },
  // created:{

  // },
  // methods:{

  // }

}
</script>
<style scoped lang='scss'>
.app-box-container{
  font-size: 50px;
  height: 100%;
  width:100%;
  margin: 0px;
  padding: 0px;
  background-color: powderblue;
}

</style>

