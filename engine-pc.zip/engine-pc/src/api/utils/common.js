import STORE from '../local_store.js'

export default {
    hasAuth:function(pageKey,key) {
        let pageAuth = STORE.getRoleAuth()[pageKey]
        let flag = false
        pageAuth.forEach(o => {
            if(o.moduleCode == key) {
                flag = true
            }
        });
        return flag
    },

    formateTime:function(time){
        if(null == time || time.length < 19) {
            return time
        }
        return time.substring(0,19).replace('T', ' ')
    }
}