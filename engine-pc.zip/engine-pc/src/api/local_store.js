export default {
    getRoleType:function(){
        return localStorage.getItem('access-roleType');
    },
    setRoleType:function(roleType){
        return localStorage.setItem('access-roleType', roleType);
    },
    setUser:function(user){
        localStorage.setItem('access-user', JSON.stringify(user));
    },
    getUser:function(){
        let userStr = localStorage.getItem('access-user');
        if(userStr != 'null' && userStr != 'undefined'){
            return JSON.parse(userStr)
        } else {
            return null
        }
    },
    setRoleList:function(roleList){
        localStorage.setItem('access-roleList', JSON.stringify(roleList));
    },
    getRoleList:function(){
        let roleListStr = localStorage.getItem('access-roleList');
        if(roleListStr != 'null'){
            return JSON.parse(roleListStr)
        } else {
            return null
        }
    },
    setRoleAuth(roleAuth){
        localStorage.setItem('access-roleAuth', JSON.stringify(roleAuth));
    },
    getRoleAuth(){
        let roleAuth = localStorage.getItem('access-roleAuth');
        if(roleAuth != 'null'){
            return JSON.parse(roleAuth)
        } else {
            return []
        }
    },
    setDeptCodes(deptCodes){
        localStorage.setItem('access-deptCodes', JSON.stringify(deptCodes));
    },
    getDeptCodes(){
        let deptCodes = localStorage.getItem('access-deptCodes');
        if(deptCodes != 'null'){
            return JSON.parse(deptCodes)
        } else {
            return []
        }
    },
    setMenu:function(menu){
        localStorage.setItem('access-menu', JSON.stringify(menu));
    },
    getMenu:function(){
        let menuStr = localStorage.getItem('access-menu');
        if(menuStr != 'null'){
            return JSON.parse(menuStr)
        } else {
            return null
        }
    },
    remove:function(){
        localStorage.removeItem('access-user')
        localStorage.removeItem('access-roleType')
        localStorage.removeItem('access-roleList')
        localStorage.removeItem('access-menu')
        localStorage.removeItem('access-roleAuth')
    }
  }
  