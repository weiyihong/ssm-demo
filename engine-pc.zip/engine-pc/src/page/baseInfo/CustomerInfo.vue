<template>
  <div class="en-container">
    <div class="en-title">
      客户信息
    </div>

    <div class="en-search">
      <el-form :inline="true">
        <el-form-item label="站点" v-if="showSearchCode">
          <el-select size="mini" v-model="search.deptCode">
            <el-option v-for="item in deptCodes" :key="item.deptCode" :label="item.deptName" :value="item.deptCode"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="联系人">
          <el-input size="mini" v-model="search.linkName" placeholder="姓名" clearable></el-input>
        </el-form-item>

        <el-form-item label="联系电话">
          <el-input size="mini" v-model="search.phone" placeholder="联系电话" clearable></el-input>
        </el-form-item>

        <el-form-item label="店名">
          <el-input size="mini" v-model="search.codeName" placeholder="名称/编码" clearable></el-input>
        </el-form-item>

        <el-form-item label="客户等级">
          <el-select size="mini" v-model="search.level">
            <el-option v-for="item in leavels" :key="item.key" :label="item.value" :value="item.key"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="状态">
          <el-select v-model="search.deleted" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='1' label='有效' value='1'></el-option>
            <el-option key='0' label='无效' value='0'></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="beginSearch" v-if="hasAuth('base_info_customer_query')">查询</el-button>
      <el-button size="mini" type="primary" @click="openAddDialog" v-if="hasAuth('base_info_customer_add')">新增</el-button>
      <el-button size="mini" type="primary" plain="plain" @click="clearSearchParam">清除</el-button>
    </div>

    <div class="en-cnt">
      <el-table ref="mainTab" :data="mainTable.data" highlight-current-row style="width: 100%">
        <el-table-column type="index" align="center" width="50"></el-table-column>
        <el-table-column property="shopCode" align="center" label="编号"></el-table-column>
        <el-table-column property="deptCode" align="center" label="站点" v-if="showSearchCode"></el-table-column>
        <el-table-column property="shopName" align="center" label="店名"></el-table-column>
        <el-table-column property="linkName" align="center" label="店长"></el-table-column>
        <el-table-column property="phone" align="center" label="联系电话"></el-table-column>
        <el-table-column show-overflow-tooltip align="center" property="addRess" label="地址"></el-table-column>
        <el-table-column property="level" align="center" label="客户等级" :formatter="customerLeaverFormater"></el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.deleted == '1'">有效</span>
            <span v-else>无效</span>
          </template>
        </el-table-column>
        <el-table-column show-overflow-tooltip align="center" property="remarks" label="备注"></el-table-column>

        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button size="mini" @click="editCustomer(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('base_info_customer_update')"></el-button>
            
            <el-button size="mini" type="danger" @click="deleteCustomer(scope.$index, scope.row)" icon="el-icon-delete" circle title="失效" v-if="hasAuth('base_info_customer_delete')"></el-button>

            <el-popover placement="top" width="300" trigger="click">
              <table class="modify-table">
                <tr>
                  <th>修改人</th>
                  <th>修改时间</th>
                </tr>
                <tr>
                  <td>{{scope.row.modifiedBy}}</td>
                  <td>{{scope.row.modifiedTm | formatData}}</td>
                </tr>
              </table>
              <el-button size="mini" type="info" slot="reference" icon="el-icon-search" circle title="查看"></el-button>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <footer class="en-footer">
     <el-pagination background layout="total, prev, pager, next" :total="mainTable.total" :current-page="search.pageNum" 
      :pageSize="search.pageSize" @current-change="pageChange" v-if="mainTable.total>0"></el-pagination>
    </footer>

    <el-dialog :title="title" :visible.sync="flag.updateDialog" width="600px">
      <el-form :inline="true" ref="updateCustomerForm" label-position="left">
        <table class="form-table">
          <tr v-if="showSearchCode">
            <td colspan="2">
              <el-form-item label="站点">
                <el-select size="mini" v-model="updateForm.deptCode" :disabled="updateCodeChange">
                  <el-option v-for="item in deptCodes" :key="item.deptCode" :label="item.deptName" :value="item.deptCode"></el-option>
                </el-select>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="编号">
                <el-input size="mini" v-model="updateForm.shopCode" placeholder="编号" :disabled="updateCodeChange" auto-complete="off"></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="店名">
                <el-input size="mini" v-model="updateForm.shopName" placeholder="店名" auto-complete="off"></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="店长">
                <el-input size="mini" v-model="updateForm.linkName" placeholder="店长" auto-complete="off"></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="电话">
                <el-input size="mini" v-model="updateForm.phone" placeholder="电话" auto-complete="off"></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="地址">
                <el-input size="mini" v-model="updateForm.addRess" placeholder="地址" auto-complete="off"></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="等级">
                <el-select size="mini" v-model="updateForm.level">
                  <el-option v-for="item in updateLeves" :key="item.key" :label="item.value" :value="item.key"></el-option>
                </el-select>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <el-form-item label="备注">
                <el-input size="mini" v-model="updateForm.remarks" placeholder="备注" auto-complete="off"></el-input>
              </el-form-item>
            </td>
          </tr>
        </table>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="updateCustomerSave()" :loading="flag.updateSaveLoading">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>
<script>

import * as API from '../../api/'
import CommonUtil from '../../api/utils/common'
import STORE from '../../api/local_store'
export default{
  data(){
    return {
      deptCodes:[],
      visible:false,
      updateCodeChange:false,
      mainTable:{
        data:[],
        total:0
      },
      leavels:[
        {
          key:'',
          value:'全部'
        }
      ],
      updateLeves:[],
      showSearchCode:true,
      search:{
        deptCode:'',
        codeName:'',
        linkName:'',
        phone:'',
        level:'',
        deleted:'1',
        pageNum:1,
        pageSize:10
      },
      updateForm:{
        id:null,
        deptCode:'',
        shopCode:'',
        shopName:'',
        linkName:'',
        addRess:'',
        phone:'',
        level:'',
        remarks:''
      },
      flag:{
        updateDialog:false,
        updateSaveLoading:false
      },
      title:''
    }
  },
  filters: {
    formatData:function(time) {
      return CommonUtil.formateTime(time)
    }
  },
  methods: {
    clearSearchParam(){
      this.search.code = ''
      this.search.linkName = ''
      this.search.phone = ''
      this.search.deleted = '1'
      this.search.level = ''
    }, 
    hasAuth:function(key){
      return CommonUtil.hasAuth('base_info_customer',key)
    },
    customerLeaverFormater:function(row, column, cellValue, index){
      let res = ''
      this.leavels.forEach(o => {
        if(o.key == cellValue) {
          res = o.value
        }
      })
      return res
    },
    setDeptCodes:function(){
      let codes = STORE.getDeptCodes()
      this.deptCodes = codes
      this.search.deptCode = codes[0].deptCode
      if(codes.length == 1) {
        this.showSearchCode = false
      } else {
        this.showSearchCode = true
      }
    },
    openAddDialog:function(){
      this.flag.updateSaveLoading = false
      this.title = '新增顾客'
      this.updateCodeChange = false
      this.updateForm.id = null
      this.updateForm = {
        id:null,
        deptCode:'',
        shopCode:'',
        shopName:'',
        linkName:'',
        addRess:'',
        phone:'',
        level:'',
        remarks:''
      }
      this.updateForm.deptCode = this.deptCodes[0].deptCode
      this.flag.updateDialog = true
      if(this.updateLeves.length > 0) {
        this.updateForm.level = this.updateLeves[0].key
      }
    },
    editCustomer:function(index,row){
      this.flag.updateSaveLoading = false
      this.title = '更新顾客信息'
      this.updateCodeChange = true
      this.flag.updateDialog = true
      this.updateForm.id = row.id
      this.updateForm.deptCode = row.deptCode
      this.updateForm.shopCode = row.shopCode
      this.updateForm.shopName = row.shopName
      this.updateForm.linkName = row.linkName
      this.updateForm.addRess = row.addRess
      this.updateForm.phone = row.phone
      this.updateForm.level = row.level
      this.updateForm.remarks = row.remarks
    },
    setLeavers:function(){
      let that = this
      API.GET('/dict/getByType/custLevel').then(result => {
        if (result && result.status === 200) {
          result.data.forEach(element => {
            let le = {}
            le.key = element.key,
            le.value = element.value
            that.leavels.push(le)
            that.updateLeves.push(le)
          });
        } else {
          that.$message.error({showClose: true, message: result.msg, duration: 2000})
        }
      },error => {
        that.$message.error({showClose: true, message: err.toString(), duration: 2000})
      }).catch(err => {
        that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
      })
    },
    beginSearch:function(){
      this.search.pageNum = 1
      this.searchCustorm()
    },
    searchCustorm:function(){
      let that = this
      API.POST('/customer/query',that.search).then(result => {
        if (result && result.status === 200) {
          that.mainTable.data = result.data.row
          that.mainTable.total = result.data.total
        } else {
          that.mainTable.data = []
          that.mainTable.total = 0
          that.$message.error({showClose: true, message: result.msg, duration: 2000})
        }
      },error => {
        that.mainTable.data = []
        that.mainTable.total = 0
        that.$message.error({showClose: true, message: error.toString(), duration: 2000})
      }).catch(err => {
        that.mainTable.data = []
        that.mainTable.total = 0
        that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
      })
    },
    pageChange: function(currentPage) {
      this.search.pageNum = currentPage
      this.searchCustorm()
    },
    updateCustomerSave:function(){
      let that = this
      that.flag.updateSaveLoading = true
      let url = that.updateForm.id == null ? '/customer/add':'/customer/update'

      const h = this.$createElement
      this.$confirm(`确认保存？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        API.POST(url,that.updateForm).then(result => {
          if (result && result.status === 200) {
            that.beginSearch()
            that.$message.info({showClose: true, message: '保存成功！', duration: 2000})
            that.flag.updateDialog = false
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.flag.updateSaveLoading = false
        },error => {
          that.flag.updateSaveLoading = false
          that.$message.error({showClose: true, message: error.toString(), duration: 2000})
        }).catch(err => {
          that.flag.updateSaveLoading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      }).catch(action => {})
    },
    deleteCustomer:function(index,row){
      let that = this
      const h = this.$createElement
      this.$confirm(`确认失效客户[${row.shopCode}(${row.shopName})]？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        let param = {}
        param.id = row.id
        API.GET('/customer/delete',param).then(result => {
          if (result && result.status === 200) {
            that.searchCustorm()
            that.$message.info({showClose: true, message: '操作成功！', duration: 2000})
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },error => {
          that.$message.error({showClose: true, message: error.toString(), duration: 2000})
        }).catch(err => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      }).catch(action => {})
    }
  },
  mounted() {
    this.setDeptCodes()
    this.setLeavers()
  }
}
</script>
<style scoped lang='scss'>
  .form-table{
    margin: 0px;
    width: 100%;
    td{
      padding: 0px;
      .el-form-item{
        margin: 0px;
        padding: 0px;
        width: 100%;
      }
    }
  }
</style>