<template>
  <div class="en-container">
    <div class="en-title">
      商品信息
    </div>

    <div class="en-search">
      <el-form :inline="true">
        <el-form-item label="站点" v-if="showSearchCode">
          <el-select size="mini" v-model="search.deptCode">
            <el-option v-for="item in deptCodes" :key="item.deptCode" :label="item.deptName" :value="item.deptCode"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="编号">
          <el-input size="mini" v-model="search.code" placeholder="编号" clearable></el-input>
        </el-form-item>
        <el-form-item label="名称">
          <el-input size="mini" v-model="search.name" placeholder="名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="search.deleted" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='1' label='有效' value='1'></el-option>
            <el-option key='0' label='无效' value='0'></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="beginSearch" v-if="hasAuth('base_info_goods_query')">查询</el-button>
      <el-button size="mini" type="primary" @click="openAddDialog" v-if="hasAuth('base_info_goods_add')">新增</el-button>
      <el-button size="mini" type="primary" plain="plain" @click="clearSearchParam">清除</el-button>
    </div>

    <div class="en-cnt">
      <el-table ref="mainTab" :data="mainTable.data" highlight-current-row style="width: 100%">
        <el-table-column type="index" align="center" width="50"></el-table-column>
        <el-table-column property="deptCode" align="center" label="站点" v-if="showSearchCode"></el-table-column>
        <el-table-column property="code" align="center" label="编号"></el-table-column>
        <el-table-column property="name" align="center" label="名称"></el-table-column>
        <el-table-column property="spec" align="center" label="规格"></el-table-column>
        <el-table-column property="netContent" align="center" label="净含量" :formatter="formatNetContent"></el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.deleted == '1'">有效</span>
            <span v-else>无效</span>
          </template>
        </el-table-column>
        <el-table-column show-overflow-tooltip align="center" property="remarks" label="备注"></el-table-column>

        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button size="mini" @click="editRow(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('base_info_goods_update')"></el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.$index, scope.row)" icon="el-icon-delete" circle title="失效" v-if="hasAuth('base_info_goods_delete')"></el-button>

            <el-popover placement="top" width="300" trigger="click">
              <table class="modify-table">
                <tr>
                  <th>修改人</th>
                  <th>修改时间</th>
                </tr>
                <tr>
                  <td>{{scope.row.modifiedBy}}</td>
                  <td>{{scope.row.modifiedTm | formatData}}</td>
                </tr>
              </table>
              <el-button size="mini" type="info" slot="reference" icon="el-icon-search" circle title="查看"></el-button>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <footer class="en-footer">
     <el-pagination background layout="total, prev, pager, next" :total="mainTable.total" :current-page="search.pageNum" 
      :pageSize="search.pageSize" @current-change="pageChange" v-if="mainTable.total>0"></el-pagination>
    </footer>

    <el-dialog :title="title" :visible.sync="flag.update" width="600px">
      <el-form :inline="true" ref="updateGoodsForm" label-position="left">
        <table class="form-table">
          <tr v-if="showSearchCode">
            <td colspan="2">
              <el-form-item label="站点">
                <el-select size="mini" v-model="update.deptCode" :disabled="flag.updateCodeChange">
                  <el-option v-for="item in deptCodes" :key="item.deptCode" :label="item.deptName" :value="item.deptCode"></el-option>
                </el-select>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="编号">
                <el-input size="mini" v-model="update.code" placeholder="编号" clearable :disabled="flag.updateCodeChange" auto-complete="off"></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="名称">
                <el-input size="mini" v-model="update.name" placeholder="名称" clearable auto-complete="off"></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="含量">
                <el-input-number size="mini" v-model="update.netContent" label="净含量"></el-input-number>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="单位">
                <el-select size="mini" v-model="update.unit">
                  <el-option v-for="item in unit" :key="item.key" :label="item.value" :value="item.key"></el-option>
                </el-select>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="规格">
                <el-input size="mini" clearable v-model="update.spec" placeholder="规格" auto-complete="off"></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="备注">
                <el-input size="mini" clearable v-model="update.remarks" placeholder="备注" auto-complete="off"></el-input>
              </el-form-item>
            </td>
          </tr>
        </table>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="updateGoodsSave()" :loading="flag.updateLoading">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>

import * as API from '../../api/'
import CommonUtil from '../../api/utils/common'
import STORE from '../../api/local_store'
export default{
  data(){
    return {
      showSearchCode:true,
      title:'新增商品',
      deptCodes:[],
      unit:[],
      search:{
        deptCode:'',
        code:'',
        name:'',
        deleted:'1',
        pageNum:1,
        pageSize:10
      },
      mainTable:{
        data:[],
        total:0
      },
      update:{
        id:null,
        deptCode:'',
        code:'',
        name:'',
        spec:'',
        netContent:'',
        unit:'',
        remarks:''
      },
      flag:{
        update:false,
        updateLoading:false,
        updateCodeChange:false
      }
    }
  },
  filters: {
    formatData:function(time) {
      return CommonUtil.formateTime(time)
    }
  },
  methods: {
    editRow:function(index,row){
      this.flag.update = true
      this.title = '商品修改'
      this.flag.updateCodeChange = true
      this.update.id = row.id
      this.update.deptCode = row.deptCode
      this.update.unit = row.unit
      this.update.name = row.name
      this.update.code = row.code
      this.update.netContent = row.netContent
      this.update.spec = row.spec
      this.update.remarks = row.remarks
    },
    openAddDialog:function(){
      this.flag.update = true
      this.flag.updateCodeChange = false
      this.title = '新增商品'
      this.update.deptCode = this.deptCodes[0].deptCode
      this.update.unit = this.unit[0].key
      this.update.id = null
      this.update.code = ''
      this.update.name = ''
      this.update.spec = ''
      this.update.netContent = 0
      this.update.remarks = ''
    },
    clearSearchParam:function(){
      this.search.deptCode = this.deptCodes[0].deptCode
      this.search.code = ''
      this.search.name = ''
      this.search.deleted = '1'
    },
    beginSearch:function(){
      this.search.pageNum = 1
      this.searchGoodsInfo();
    },
    pageChange: function(currentPage) {
      this.search.pageNum = currentPage
      this.searchGoodsInfo()
    },
    searchGoodsInfo:function(){
      let that = this
      API.POST('/goods/query',this.search).then(result => {
        if (result && result.status === 200) {
          that.mainTable.data = result.data
          that.mainTable.total = result.total
        } else {
          that.mainTable.data = []
          that.mainTable.total = 0
          that.$message.error({showClose: true, message: result.msg, duration: 2000})
        }
      },error => {
        that.mainTable.data = []
        that.mainTable.total = 0
        that.$message.error({showClose: true, message: error.toString(), duration: 2000})
      }).catch(err => {
        that.mainTable.data = []
        that.mainTable.total = 0
        that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
      })
    },
    formatNetContent:function(row){
      let num = row.netContent
      let unitKey = row.unit
      let unit = ''
      this.unit.forEach(o => {
        if(o.key == unitKey) {
          unit = o.value
        }
      })
      return `${num}(${unit})`
    },
    setDeptCodes:function(){
      let codes = STORE.getDeptCodes()
      this.deptCodes = codes
      this.search.deptCode = codes[0].deptCode
      if(codes.length == 1) {
        this.showSearchCode = false
      } else {
        this.showSearchCode = true
      }
    },
    updateGoodsSave:function(){
      let that = this
      const h = this.$createElement
      this.$confirm(`确定保存该记录？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        let url = that.update.id == null ? '/goods/add':'/goods/update'
        that.flag.updateLoading = true
        API.POST(url,that.update).then(result => {
          if (result && result.status === 200) {
            that.flag.updateLoading = false
            that.flag.update = false
            that.beginSearch()
          } else {
            that.flag.updateLoading = false
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },error => {
          that.flag.updateLoading = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(err => {
          that.flag.updateLoading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      }).catch(action => {})
    },
    deleteRow:function(index,row){
      let that = this
      const h = this.$createElement
      this.$confirm(`确定删除记录${row.name}[${row.code}]？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        API.GET('/goods/delete',{id:row.id}).then(result => {
          if (result && result.status === 200) {
            that.beginSearch()
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },error => {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(err => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      }).catch(action => {})
    },
    setUnit:function(){
      let that = this
      API.GET('/dict/getByType/goodsUnit').then(result => {
        if (result && result.status === 200) {
          result.data.forEach(element => {
            let le = {}
            le.key = element.key,
            le.value = element.value
            that.unit.push(le)
          });
        } else {
          that.$message.error({showClose: true, message: result.msg, duration: 2000})
        }
      },error => {
        that.$message.error({showClose: true, message: err.toString(), duration: 2000})
      }).catch(err => {
        that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
      })
    },
    hasAuth:function(key){
      return CommonUtil.hasAuth('base_info_goods',key)
    },
  },
  mounted() {
    this.setDeptCodes()
    this.setUnit()
  }
}
</script>
<style scoped lang='scss'>
  .form-table{
    margin: 0px;
    width: 100%;
    td{
      padding: 0px;
      .el-form-item{
        margin: 0px;
        padding: 0px;
        width: 100%;
      }
    }
  }
</style>

