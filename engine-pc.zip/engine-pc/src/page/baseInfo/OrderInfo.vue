<template>
  <div class="app-container">
    <div class="app-top">
      <li></li>
      <li>订单管理</li>
      <li></li>        
      <li @click="toMainPage">返回主页</li>
      <li></li>
    </div>

    <div class="app-cnt">
      <mt-button type="default">default</mt-button>
      <mt-button type="danger" size="normal">danger</mt-button>
    </div>

    <div class="app-footer">
      <div class="item">金额</div>
      <div class="item">
        <input v-model="total" type="number" disabled/>
      </div>
      <div class="item">实付</div>
      <div>
        <input v-model="full" type="number"/>
      </div>
      <div class="app-button" @click="submit">
        确认
      </div>
    </div>
    
  </div>
</template>
<script>

import * as API from '../../api/'
import CommonUtil from '../../api/utils/common'
import STORE from '../../api/local_store'
import { MessageBox,Toast,Button } from 'mint-ui'

export default{
  components:{
    Button
  },
  data(){
    return {
      total:100,
      full:0
    }
  },
  filters: {
    
  },
  methods: {
    jumpTo:function(url){
      this.defaultActiveIndex = url;
      this.$router.push(url); //用go刷新
    },
    toMainPage:function(){
      let that = this
      // MessageBox.confirm('确认返回主页?').then(action => {
      //   console.log(action)
      // })
      Toast({
  message: 'operation success',
  iconClass: 'icon icon-success'
});
    },
    submit:function(){
      console.log(this.full)
    }
  },
  mounted() {
    
  }
}
</script>
<style scoped lang='scss'>
.app-container{
  width: 100%;
  margin: 0px;
  padding: 0px;
  overflow: hidden;
  display: flex;
  flex-direction: column;

  .app-top{
    width: 100%;
    margin: 0px;
    padding: 0;
    height: 40px;
    display: flex;

    flex-direction: row;
    background-color: #4cb4e7;

    li {
      list-style-type: none;
      color: #fff;
      line-height: 40px;
    }
  }
  .app-cnt{
    width: 100%;
    margin: 0px;
    flex:1;
  }
  .app-footer{
    width: 100%;
    margin: 0px;
    padding: 10px;
    height: 100px;
    display: flex;

    flex-direction: row;
    background-color: #4cb4e7;

    .item {
      flex: 1;
      font-size: 50px;
      color: #fff;
      line-height: 100px;
      text-align: center;
    }
    input {
      font-size: 40px;
      line-height: 60px;
      margin: 10px;
      padding: 10px;
      width: 200px;
      border-radius: 20px;
    }
  }
}
.app-button {
  width: 200px;
  background-color: #edd0be;
  border-radius: 40px;
  font-size: 50px;
  line-height: 80px;
  margin: 10px 30px 10px 30px;
  text-align: center;
}
</style>