<template>
  <div class="en-container">
    <div class="en-title">
      员工信息
    </div>

    <div class="en-search">
      <el-form :inline="true">
        <el-form-item label="编码">
          <el-input size="mini" v-model="search.code" placeholder="用户编码" clearable></el-input>
        </el-form-item>
        <el-form-item label="名称">
          <el-input size="mini" v-model="search.name" placeholder="用户名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input size="mini" v-model="search.addRess" placeholder="地址" clearable></el-input>
        </el-form-item>
        <el-form-item label="手机">
          <el-input size="mini" v-model="search.phone" placeholder="手机号码" clearable></el-input>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="search.deleted" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='1' label='有效' value='1'></el-option>
            <el-option key='0' label='无效' value='0'></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="性别">
          <el-select v-model="search.sex" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='0' label='男' value='0'></el-option>
            <el-option key='1' label='女' value='1'></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="beginSearch" :loading="loading.main" v-if="hasAuth('base_info_user_query')">查询</el-button>
      <el-button size="mini" type="primary" @click="addRecord" plain v-if="hasAuth('base_info_user_add')">新增</el-button>
      <el-button size="mini" type="primary" plain @click="clearSearchParam">清除</el-button>
    </div>

    <div class="en-cnt">
      <el-table ref="mainTab" :data="data.list" highlight-current-row style="width: 100%">
        <el-table-column type="index" width="50"></el-table-column>
        <el-table-column property="code" label="编码"></el-table-column>
        <el-table-column property="name" label="名称"></el-table-column>
        <el-table-column property="phone" label="手机"></el-table-column>
        <el-table-column property="addRess" label="地址"></el-table-column>
        <el-table-column label="性别">
          <template slot-scope="scope">
            <span v-if="scope.row.sex == '0'">男</span>
            <span v-else-if="scope.row.sex == '1'">女</span>
            <span v-else></span>
          </template>
        </el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.deleted == '1'">有效</span>
            <span v-else>无效</span>
          </template>
        </el-table-column>
        <!-- <el-table-column show-overflow-tooltip property="modifiedTm" label="修改时间" :formatter="dateFormatter"></el-table-column>
        <el-table-column property="modifiedBy" label="修改人"></el-table-column>
        <el-table-column label="操作" v-if="hasAuth('base_info_user_update') || hasAuth('base_info_user_delete')">
          <template slot-scope="scope">
            <el-button size="mini" @click="editUser(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('base_info_user_update')"></el-button>
            <el-button size="mini" type="danger" @click="deleteUser(scope.$index, scope.row)" icon="el-icon-star-on" circle title="失效" v-if="hasAuth('base_info_user_delete')"></el-button>
          </template>
        </el-table-column> -->

        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button size="mini" @click="editUser(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('base_info_user_update')"></el-button>
            <el-button size="mini" type="danger" @click="deleteUser(scope.$index, scope.row)" icon="el-icon-star-on" circle title="失效" v-if="hasAuth('base_info_user_delete')"></el-button>

            <el-popover placement="top" width="300" trigger="click">
              <table class="modify-table">
                <tr>
                  <th>修改人</th>
                  <th>修改时间</th>
                </tr>
                <tr>
                  <td>{{scope.row.modifiedBy}}</td>
                  <td>{{scope.row.modifiedTm | formatData}}</td>
                </tr>
              </table>
              <el-button size="mini" type="info" slot="reference" icon="el-icon-search" circle title="查看"></el-button>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <footer class="en-footer">
      <el-pagination background layout="total, prev, pager, next" :total="data.total" :current-page="search.pageNum" :pageSize="search.pageSize" @current-change="pageChange" v-if="data.total>0"></el-pagination>
    </footer>

    <el-dialog :title="title" :visible.sync="dailog.add" width="400px">
      <el-form :inline="true" ref="addUserInfoForm" label-position="left">
        <el-form-item label="编码">
          <el-input size="mini" v-model="add.code" placeholder="客户编码" auto-complete="off" :disabled="codeEdit"></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input size="mini" v-model="add.name" placeholder="客户姓名" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="手机">
          <el-input size="mini" v-model="add.phone" placeholder="手机号码" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input size="mini" v-model="add.addRess" placeholder="客户地址" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-radio-group v-model="add.sex">
            <el-radio :label="0">男</el-radio>
            <el-radio :label="1">女</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="addUserSave()" :loading="loading.add">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>

import * as API from '../../api/'
import CommonUtil from '../../api/utils/common'
import STORE from '../../api/local_store'
export default{
  data(){
    return {
      loading: {
          main:false,
          add:false
      },
      dailog:{
        add:false
      },
      search:{
          code:'',
          name:'',
          sex:'',
          phone:'',
          deleted:'1',
          addRess:'',
          pageNum:1,
          pageSize:10
      },
      data: {
          list:[],
          total: 0
      },
      add:{
        id:'',
        code:'',
        name:'',
        sex:0,
        phone:'',
        addRess:''
      },
      title:'',
      type:'',
      codeEdit:false
    }
  },
  filters: {
    formatData:function(time) {
      return CommonUtil.formateTime(time)
    }
  },
  methods: {
    clearSearchParam:function(){
        this.search.code = ''
        this.search.name = ''
        this.search.phone = ''
        this.search.deleted = '1'
        this.search.sex = ''
        this.search.pageNum = 1
        this.search.pageSize = 10
    },
    userSearch:function(){
        let that = this
        API.POST('/sysUser/query',that.search).then(result => {
            if (result && result.status === 200) {
                that.data.list = result.data
                that.data.total = result.total
            } else {
                that.data.list = []
                that.data.total = 0
                that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
        },err => {
            that.data.list = []
            that.data.total = 0
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(err => {
            that.data.list = []
            that.data.total = 0
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
    },
    addRecord:function(){
      this.title = '新增用户'
      this.type = 'add'
      this.codeEdit = false
      this.add = {
        id:'',
        code:'',
        name:'',
        sex:0,
        phone:'',
        addRess:''
      }
      this.loading.add = false
      this.dailog.add = true
    },
    editUser:function(index,row){
      this.type = 'update'
      this.codeEdit = true
      this.title = '修改用户'
      this.add = {
        id:row.id,
        code:row.code,
        name:row.name,
        sex:row.sex == '0' ? 0 : 1,
        phone:row.phone,
        addRess:row.addRess
      }
      this.loading.add = false
      this.dailog.add = true
    },
    addUserSave:function(){
      let that = this
      let url = this.type == 'add' ? '/sysUser/add':'/sysUser/update'
      this.$confirm(`确认保存该记录？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        that.loading.add = true
        API.POST(url,that.add).then(result => {
          if (result && result.status === 200) {
            that.beginSearch()
            that.dailog.add = false
            that.$message.info({showClose: true, message: '保存客户成功！', duration: 2000})
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.loading.add = false
        },err => {
          that.loading.add = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(err => {
          that.loading.add = false
          that.$message.error({showClose: true, message: '请求出现异常！', duration: 2000})
        })
      }).catch(action => {})
    },
    deleteUser:function(index,row){
      let that = this
      this.$confirm(`确认失效该记录？`, '确认', {
        distinguishCancelAndClose: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(() => {
        let param = {id:row.id}
        API.GET('/sysUser/delete',param).then(result => {
          if (result && result.status === 200) {
            that.beginSearch()
            that.$message.info({showClose: true, message: '失效客户成功！', duration: 2000})
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(err => {
          that.$message.error({showClose: true, message: '请求出现异常！', duration: 2000})
        })
      }).catch(action => {})
    },
    dateFormatter:function(row, column, cellValue, index){
      return CommonUtil.formateTime(cellValue)
    },
    beginSearch:function(){
      this.search.pageNum = 1
      this.loading.main = true
      this.userSearch()
      this.loading.main = false
    },
    pageChange: function(currentPage) {
      this.search.pageNum = currentPage
      this.userSearch()
    },
    hasAuth(key){
      return CommonUtil.hasAuth('base_info_user',key)
    },
    setDeptCodes(){
      let deptCodes = STORE.getDeptCodes()
    }
  },
  mounted() {
    this.setDeptCodes()
  }
}
</script>
<style scoped lang='scss'>

</style>

