<template>
  <div class="en-container">
    <div class="en-title">
      欢迎界面
    </div>

    <div class="en-cnt">
      <h1>欢迎来到后台管理系统</h1>
    </div>
  </div>
</template>
<script>

export default{
  data(){
    return {
      
    }
  },
  methods: {
    
  }
}
</script>
