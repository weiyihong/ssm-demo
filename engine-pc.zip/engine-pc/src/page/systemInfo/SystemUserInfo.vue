<template>
  <div class="en-container" element-loading-text="拼命加载中">
    <div class="en-title">
      用户信息
      <!-- <el-button size="mini" type="primary" class="en_button" @click="beginDownload">导入</el-button>
      <el-button size="mini" type="primary" class="en_button" @click="userInfoExport" :loading="loading">导出</el-button> -->
    </div>
    <!--查询条件-->
    <div class="en-search">
      <el-form :inline="true">
        <el-form-item label="用户编码">
          <el-input size="mini" v-model="param.code" placeholder="用户编码" clearable></el-input>
        </el-form-item>
        <el-form-item label="用户名称">
          <el-input size="mini" v-model="param.name" placeholder="用户名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="性别">
          <el-select v-model="param.sex" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='0' label='男' value='0'></el-option>
            <el-option key='1' label='女' value='1'></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="param.deleted" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='1' label='有效' value='1'></el-option>
            <el-option key='0' label='无效' value='0'></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="userSearch" v-if="hasAuth('sys_user_conf_query')">查询</el-button>
      <el-button size="mini" type="primary" plain @click="addUserf" v-if="hasAuth('sys_user_conf_add')">新增</el-button>
      <el-button size="mini" type="primary" plain @click="clearSearchParam">清除</el-button>
    </div>

    <!-- 查询结果显示 -->
    <div class="en-cnt">
      <el-table ref="systemUserInfoTab" :data="data.list" highlight-current-row style="width: 100%">
        <el-table-column type="index" width="50"></el-table-column>
        <el-table-column property="code" label="用户编码"></el-table-column>
        <el-table-column property="name" label="用户名称"></el-table-column>
        <el-table-column label="性别">
          <template slot-scope="scope">
            <span v-if="scope.row.sex == '0'">男</span>
            <span v-else-if="scope.row.sex == '1'">女</span>
            <span v-else></span>
          </template>
        </el-table-column>
        <el-table-column label="角色">
          <template slot-scope="scope">
            <div v-for="(role,index) in scope.row.roleList" :key="index">{{role.name}}</div>
          </template>
        </el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.deleted == '1'">有效</span>
            <span v-else>无效</span>
          </template>
        </el-table-column>
        <el-table-column property="modifiedTm" label="修改时间" :formatter="dateFormatter" width="200px"></el-table-column>
        <el-table-column property="modifiedBy" label="修改人"></el-table-column>
        <el-table-column label="操作" v-if="hasAuth('sys_user_conf_update') || hasAuth('sys_user_conf_pwd')">
          <template slot-scope="scope">
            <el-button size="mini" @click="editUser(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('sys_user_conf_update')"></el-button>
            <el-button size="mini" type="danger" @click="resetPwd(scope.$index, scope.row)" icon="el-icon-star-on" circle title="重置密码" v-if="hasAuth('sys_user_conf_pwd')"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <footer class="en-footer">
      <el-pagination background layout="total, prev, pager, next" :total="data.total" :current-page="param.pageNum" :pageSize="param.pageSize" @current-change="pageChange" v-if="data.total>0"></el-pagination>
    </footer>

    <el-dialog title="修改用户" size="mini" :visible.sync="updateUser.dailog" width="400px">
      <el-form :inline="true">
        <el-form-item label="用户编码">
          <el-input size="mini" v-model="updateUser.row.code" disabled></el-input>
        </el-form-item>
        <el-form-item label="用户名称">
          <el-input size="mini" v-model="updateUser.row.name" placeholder="用户名称"></el-input>
        </el-form-item>
        <el-form-item label="角色列表">
          <el-select size="mini" v-model="updateUser.row.roleList" multiple placeholder="请选择角色">
            <el-option-group
              v-for="group in userRoles"
              :key="group.id"
              :label="group.sysName">
              <el-option
                v-for="item in group.roleList"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-option-group>
          </el-select>
        </el-form-item>

        <el-form-item label="用户状态">
          <el-select v-model="updateUser.row.deleted" size="mini">
            <el-option key='1' label='有效' value='1'></el-option>
            <el-option key='0' label='无效' value='0'></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户性别">
          <el-radio-group v-model="updateUser.row.sex">
            <el-radio :label="0">男</el-radio>
            <el-radio :label="1">女</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini"  @click="userSave()" :loading="updateUser.loading">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="新增用户" :visible.sync="addUser.dailog" width="400px">
      <el-form :inline="true" ref="addUserInfoForm" :rules="rules" :model="addUser.row" label-position="left">
        <el-form-item label="用户编码" prop="code">
          <el-input size="mini" v-model="addUser.row.code" placeholder="用户编码" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="用户名称" prop="name">
          <el-input size="mini" v-model="addUser.row.name" placeholder="用户名称" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="角色列表">
          <el-select size="mini" v-model="addUser.row.roleList" multiple placeholder="请选择角色">
            <el-option-group
              v-for="group in userRoles"
              :key="group.id"
              :label="group.sysName">
              <el-option
                v-for="item in group.roleList"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-option-group>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-radio-group v-model="addUser.row.sex">
            <el-radio :label="0">男</el-radio>
            <el-radio :label="1">女</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="addUserL()" :loading="addUser.loading">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="文件上传" :visible.sync="upload.dailog" width="550px">
      <el-upload
        ref="userInfoUpload"
        drag
        :auto-upload="false"
        :limit="1"
        :action="upload.url"
        :before-upload="beforeUpload"
        :onSuccess="uploadSuccess"
        multiple>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
      </el-upload>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="submitUpload" :loading="upload.loading">确认导入</el-button>
        <el-button size="small" type="primary" @click="downLoadTemp">下载模板</el-button>
      </span>
    </el-dialog>
  </div>
</template>


<script>
  import * as API from '../../api/';
  import STORE from '../../api/local_store';
  import UTIL from '../../common/util';
  import CommonUtil from '../../api/utils/common';

  export default {
    data() {
      return {
        upload:{
          dailog:false,
          url:`${API.BaseUrl}/user/importExcel`,
          loading:false
        },
        loading:false,
        common: {
          systems:[],
          sysTemsForUpdate:[]
        },
        export: {
          count:0
        },
        param:{
          code:'',
          name:'',
          sex:'',
          deleted:'',
          pageNum:1,
          pageSize:10
        },
        data:{
          list:[],
          total:0
        },
        addUser:{
          dailog:false,
          loading:false,
          row:{
            code:'',
            came:'',
            sex:0,
            roleList:[]
          }
        },
        rules:{
          code: [
            {required: true, message: '用户编码不能为空！', trigger: 'blur'}
          ],
          name: [
            {required: true, message: '用户名称不能为空！', trigger: 'blur'}
          ]
        },
        updateUser:{
          dailog:false,
          loading:false,
          row:{
            id:'',
            code:'',
            name:'',
            sex:0,
            deleted:'',
            roleList:[]
          }
        },
        userRoles:[]
      }
    },
    methods: {
      querySysRole: function(){
        let that = this
        API.GET('/role/sysRole').then(result => {
          if (result && result.status === 200) {
            that.userRoles = result.data
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      clearSearchParam:function(){
        this.param = {
          code:'',
          name:'',
          sex:'',
          deleted:'',
          pageNum:1,
          pageSize:10
        }
      },
      userSearch:function(){
        this.param.pageNum = 1
        this.queryUser()
      },
      userInfoExport: function(){
        let that = this
        that.loading = true
        API.userInfo.export(that.param).then(result => {
          if (result && result.status === 200) {
            that.export.count = 0
            setTimeout(() => {
              that.queryExpotrTask(result.data)
            }, 3000)
          } else {
            that.loading = false
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.loading = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      queryExpotrTask:function(id){
        let that = this
        that.export.count ++
        let param = {
          taskId:id
        }
        API.taskCommon.takeResult(param).then(result => {
          if (result && result.success === 'success') {
            if(result.data == null) {
              if(that.export.count < 4){
                setTimeout(() => {
                  that.queryExpotrTask(id)
                }, 3000)
              } else {
                that.loading = false
                that.$message.error({showClose: true, message: '下载文件失败!', duration: 2000})
              }
            } else {
              self.location.href=`${API.taskCommon.download}${id}`
              that.loading = false
            }
          } else {
            that.loading = false
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.loading = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      queryUser: function(){
        let that = this
        API.POST('/user/query',that.param).then(result => {
          if (result && result.status === 200) {
            that.data.list = result.data
            that.data.total = result.total
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      dateFormatter:function(row, column, cellValue, index){
        // UTIL.formatDate.format(date,'yyyy-MM-dd hh:mm:ss')
        return cellValue.substring(0,19).replace('T', ' ')
      },
      pageChange: function(currentPage) {
        this.param.pageNum = currentPage
        this.queryUser()
      },
      editUser:function(index,row){
        let that = this
        that.updateUser.row.id = row.id
        that.updateUser.row.code = row.code
        that.updateUser.row.name = row.name
        that.updateUser.row.sex = row.sex == 1 ? 1 : 0
        that.updateUser.row.deleted = row.deleted = 1 ? '1':'0'
        that.updateUser.row.roleList = []
        that.updateUser.loading = false
        row.roleList.forEach(r => {
          that.updateUser.row.roleList.push(r.id)
        })
        that.updateUser.dailog = true
      },
      userSave:function(){
        let that = this
        const h = this.$createElement;
        this.$confirm(`确认修改该用户信息？`, '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          that.updateUser.loading = true
          API.POST('/user/update',that.updateUser.row).then(result => {
            if (result && result.status === 200) {
              that.updateUser.loading = false
              that.updateUser.dailog = false
              that.queryUser()
              that.$message.info({showClose: true, message: '更新用户信息成功！', duration: 2000})
            } else {
              that.updateUser.loading = false
              that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
          },err => {
            that.updateUser.loading = false
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
          }).catch(error => {
            that.updateUser.loading = false
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
          })
        }).catch(action => {
            
        })
      },
      addUserf:function(){
        let that = this
        that.addUser.row = {
          code:'',
          came:'',
          sex:0,
          roleList:[]
        }
        that.addUser.loading = false
        that.addUser.dailog = true
      },
      addUserL:function(){
        let that = this
        that.$refs.addUserInfoForm.validate((valid) => {
          if (valid) {
            const h = this.$createElement;
            this.$confirm(`确认修改该用户信息？`, '确认', {
              distinguishCancelAndClose: true,
              confirmButtonText: '确定',
              cancelButtonText: '取消'
            }).then(() => {
              that.addUser.loading = true
              API.POST('/user/add',that.addUser.row).then(result => {
                if (result && result.status === 200) {
                  that.addUser.dailog = false
                  that.queryUser()
                  that.$message.info({showClose: true, message: '添加用户信息成功！', duration: 2000})
                } else {
                  that.$message.error({showClose: true, message: result.msg, duration: 2000})
                }
                that.addUser.loading = false
              },err => {
                that.addUser.loading = false
                that.$message.error({showClose: true, message: err.toString(), duration: 2000})
              }).catch(error => {
                that.addUser.loading = false
                that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
              })
            }).catch(action => {
            
            })
          }
        })
      },
      resetPwd:function(index,row) {
        const h = this.$createElement;
        this.$confirm(`确认重置[${row.name}(${row.code})]的密码吗？ 重置后密码与用户编码保持一致！`, '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          let that = this
          let param = {
            userId: row.id
          }
          API.GET('/user/resetPwd',param).then(result => {
            if (result && result.status === 200) {
              that.queryUser()
              that.$message.info({showClose: true, message: '重置密码成功！', duration: 2000})
            } else {
              that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
          },err => {
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
          }).catch(error => {
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
          })
        }).catch(action => {
            
        });
      },
      hasAuth(key){
        return CommonUtil.hasAuth('sys_user_conf',key)
      },
      beginDownload(){
        this.upload.loading = false
        this.upload.dailog = true
      },
      downLoadTemp(){
        self.location.href=`${API.taskCommon.tempDownLoad}/systemUser`
      },
      beforeUpload(){
        this.upload.loading = true
      },
      submitUpload(){
        this.$refs.userInfoUpload.submit();
      },
      uploadSuccess (res, file, fileList) {
        if(res.success == 'success') {
          this.$refs.userInfoUpload.clearFiles()
          this.$message.info({showClose: true, message: '文件上传成功！', duration: 2000})
          this.upload.dailog = false
        } else {
          this.$message.error({showClose: true, message: res.msg, duration: 2000})
        }
        this.upload.loading = false
      },
    },
    mounted() {
      this.querySysRole()
    }
  }
</script>

<style scoped lang='scss'>
.updateUserTab {
  td {
    padding: 5px;
  }
}
</style>
