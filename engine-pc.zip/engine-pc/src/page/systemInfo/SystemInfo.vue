<template>
  <div class="en-container" v-loading="common.loading" element-loading-text="拼命加载中">
    <div class="en-title">
      系统设置
    </div>
    <!--查询条件-->
    <div class="en-search">
      <el-form :inline="true" :model="system.filters">
        <el-form-item label="系统编码">
          <el-input size="mini" v-model="system.filters.systemCode" placeholder="系统编码" style="min-width: 200px;" clearable></el-input>
        </el-form-item>
        <el-form-item label="系统名称">
          <el-input size="mini" v-model="system.filters.systemName" placeholder="系统名称" style="min-width: 200px;" clearable></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="systemInfoSearch" v-if="hasAuth('system_conf_query')">查询</el-button>
      <el-button size="mini" plain type="primary" @click="addSystem" v-if="hasAuth('system_conf_add')">新增</el-button>
      <el-button size="mini" type="primary" plain="plain" @click="clearSearchParam">清除</el-button>
    </div>
    <!-- 查询结果显示 -->
    <div class="en-cnt">
      <el-table ref="singleTable" :data="system.data.list" highlight-current-row style="width: 100%" v-loading="common.loading">
        <el-table-column type="index" width="50" ></el-table-column>
        <el-table-column property="sysCode" label="系统编码"></el-table-column>
        <el-table-column property="sysName" label="系统名称"></el-table-column>
        <el-table-column property="sysDesc" label="系统描述"></el-table-column>
        <el-table-column label="操作" v-if="hasAuth('system_conf_update') || hasAuth('system_conf_delete')">
          <template slot-scope="scope">
            <el-button size="mini" @click="editSystem(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改" v-if="hasAuth('system_conf_update')"></el-button>
            <el-button size="mini" type="danger" @click="deleteSystem(scope.$index, scope.row)" icon="el-icon-delete" circle title="删除" v-if="hasAuth('system_conf_delete')"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog title="系统编辑" :visible.sync="common.sysEditDig" width="500px" v-loading="common.loading">
      <table style="width:300px;">
        <tr>
          <td>系统编码：</td>
          <td>
            <el-input size="mini" placeholder="系统编码" v-model="edit.row.sysCode" disabled></el-input>
          </td>
        </tr>
        <tr>
          <td>系统名称：</td>
          <td>
            <el-input size="mini" placeholder="系统名称" v-model="edit.row.sysName"></el-input>
          </td>
        </tr>
        <tr>
          <td>系统描述：</td>
          <td>
            <el-input size="mini" placeholder="系统描述" v-model="edit.row.sysDesc"></el-input>
          </td>
        </tr>
      </table>

      <div class="menu_div">
        <el-tree
          :data="menu.list"
          show-checkbox
          node-key="id"
          :default-expanded-keys="menu.expandId"
          :default-checked-keys="menu.checked"
          :props="menu.prop"
          ref = 'sysTemMenuTre'>
        </el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="saveSystem()" :loading="edit.loading">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="系统新增" :visible.sync="common.sysAddDig" width="600px" v-loading="common.loading">
      <div style="border:1px dotted #ccc;padding:5px;">
        <table style="width:100%;">
          <tr align="right">
            <td style="width:100px;">系统编码：</td>
            <td style="width:200px;"><el-input size="mini" placeholder="系统编码" v-model="add.sysCode"></el-input></td>
            <td style="width:100px;">角色编码：</td>
            <td style="width:200px;"><el-input size="mini" placeholder="角色编码" v-model="add.code"></el-input></td>
          </tr>
          <tr align="right">
            <td>系统名称：</td>
            <td><el-input size="mini" placeholder="系统名称" v-model="add.sysName"></el-input></td>
            <td>角色名称：</td>
            <td><el-input size="mini" placeholder="角色名称" v-model="add.name"></el-input></td>
          </tr>
          <tr align="right">
            <td>系统描述：</td>
            <td><el-input size="mini" placeholder="系统描述" v-model="add.sysDesc"></el-input></td>
            <td>角色描述：</td>
            <td><el-input size="mini" placeholder="角色描述" v-model="add.desc"></el-input></td>
          </tr>
        </table>
      </div>     
      <div class="menu_div">
        <el-tree
          :data="menu.list"
          show-checkbox
          node-key="id"
          :default-expanded-keys="menu.expandId"
          :default-checked-keys="menu.checked"
          :props="menu.prop"
          ref = 'sysTemMenuAddTre'>
        </el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="addSystemSave()" :loading="add.loading">保存</el-button>
      </span>
    </el-dialog>
    <!-- <footer style="background: #eee;position: absolute;bottom: 20px;height: 50px; right:50px;">ssdfsfdsf双方各地方广东省</footer> -->
  </div>
</template>

<script>
  import * as API from '../../api/';
  import STORE from '../../api/local_store';
  import CommonUtil from '../../api/utils/common';

  export default {
    data() {
      return {
        common: {
          loading: false,
          sysEditDig:false,
          sysAddDig:false,
          roleAuth:[]
        },
        system: {
          filters:{
            systemCode:'',
            systemName:''
          },
          data: {
            list:[]
          }
        },
        edit:{
          row:{},
          loading:false
        },
        add:{
          sysCode:'',
          sysName:'',
          sysDesc:'',
          roleCode:'',
          roleName:'',
          roleDesc:'',
          moduleIds:[],
          loading:false
        },
        menu: {
          list:[],
          expandId:[],
          systemMenu: [],
          checked:[],
          prop:{
            children: 'children',
            label: 'label'
          }
        }
      }
    },
    methods: {
      clearSearchParam:function(){
        this.system.filters = {
          systemCode:'',
          systemName:''
        }
      },
      systemInfoSearch: function () {
        let that = this
        let params = {
          sysCode:that.system.filters.systemCode,
          sysName:that.system.filters.systemName
        }
        API.POST('/system/query',params).then(result => {
          if (result && result.status == 200) {
            that.system.data.list = result.data
          } else {
            that.system.data.list = []
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.system.data.list = []
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.system.data.list = []
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      editSystem: function(index,row) {
        let that = this
        that.edit.row.sysId = row.id
        that.edit.row.sysCode = row.sysCode
        that.edit.row.sysName = row.sysName
        that.edit.row.sysDesc = row.sysDesc
        that.edit.loading = false
        let param = {
          sysId:row.id
        }
        that.queryMeny(param)
      },
      addSystem: function(){
        let that = this
        that.add.sysCode = ''
        that.add.sysName = ''
        that.add.sysDesc = ''
        that.add.code = ''
        that.add.name = ''
        that.add.desc = ''
        that.add.loading = false
        let param = {}
        that.queryMeny(param,false)
      },
      queryMeny: function(param,edit = true) {
        let that = this
        API.GET('/system/queryMenu',param).then(result => {
          if (result && result.status == 200) {
            that.menu.checked = [];
            that.menu.systemMenu = result.data.sysMenu
            that.setTreeData(result.data.menu.childs)
            if(edit) {
              that.common.sysEditDig = true
            } else {
              that.common.sysAddDig = true
            }
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.common.loading = false
        },err => {
          that.common.loading = false
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.common.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      deleteSystem: function(index,row){
        const h = this.$createElement;
        this.$confirm(`确认删除[${row.sysName}]？`, '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          let that = this
          that.common.loading = true
          let param = {
            sysId: row.id
          }
          API.GET('/system/delete',param).then(result => {
          if (result && result.success === 'success') {
            that.$message.info({showClose: true, message: '删除子系统成功！', duration: 2000})
          that.systemInfoSearch()
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.common.loading = false
        },err => {
          that.common.loading = false
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.common.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
        }).catch(action => {
            
        });
      },
      setTreeData: function (menu) {
        let that = this
        let result = []
        if(menu != null) {
          for ( let i = 0; i < menu.length; i++){
            result[i] = {}
            let id = menu[i].id
            result[i].id = id
            that.menu.expandId.push(id)
            result[i].label = menu[i].name
            let nextNode = that.setTreeData(menu[i].childs)
            result[i].children = nextNode
            if(nextNode.length <1){
              that.menu.systemMenu.forEach(e => {
                if(e===id){
                  that.menu.checked.push(id)
                }
              })
            }
          }
        }
        that.menu.list = result
        return result
      },
      saveSystem: function(){
        let that = this
        let ids = []
        that.$refs.sysTemMenuTre.getCheckedNodes().forEach(node => ids.push(node.id));
        that.$refs.sysTemMenuTre.getHalfCheckedNodes().forEach(node => ids.push(node.id));
        that.edit.loading = true
        let param = {
          id:that.edit.row.sysId,
          moduleIds:ids,
          sysName:that.edit.row.sysName,
          sysDesc:that.edit.row.sysDesc
        }
        API.POST('/system/update',param).then(result => {
          if (result && result.status == 200) {
            that.$message.info({showClose: true, message: '保存成功！', duration: 2000})
            that.common.sysEditDig = false
            that.systemInfoSearch()
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.edit.loading = false
        },err => {
          that.edit.loading = false
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.edit.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      addSystemSave: function(){
        let that = this
        that.add.loading = true
        let ids = []
        that.$refs.sysTemMenuAddTre.getCheckedNodes().forEach(node => ids.push(node.id));
        that.$refs.sysTemMenuAddTre.getHalfCheckedNodes().forEach(node => ids.push(node.id));
        that.add.moduleIds = ids
        API.POST('/system/add',that.add).then(result => {
          if (result && result.status == 200) {
            that.$message.info({showClose: true, message: '添加系统成功！', duration: 2000})
            that.systemInfoSearch()
            that.common.sysAddDig = false
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
          that.add.loading = false
        },err => {
          that.add.loading = false
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.add.loading = false
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      hasAuth(key){
        return CommonUtil.hasAuth('system_conf',key)
      }
    },
    mounted() {
      this.common.roleAuth = STORE.getRoleAuth().system_conf
    }
  }
</script>

<style scoped>
.menu_div {
  height: 400px;
  overflow: auto;
}
</style>
