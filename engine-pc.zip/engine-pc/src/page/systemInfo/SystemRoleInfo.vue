<template>
  <div class="en-container" element-loading-text="拼命加载中" v-loading="common.loading">
    <div class="en-title">
      系统角色设置
    </div>
    <!--查询条件-->
    <div class="en-search">
      <el-form :inline="true" :model="param">
        <el-form-item label="角色编码">
          <el-input size="mini" v-model="param.code" placeholder="角色编码" clearable></el-input>
        </el-form-item>
        <el-form-item label="角色名称">
          <el-input size="mini" v-model="param.name" placeholder="角色名称" clearable></el-input>
        </el-form-item>
        <el-form-item label="角色类型">
          <el-select v-model="param.type" size="mini" clearable>
            <el-option key='' label='全部' value=''></el-option>
            <el-option key='2' label='系统管理员' value='2'></el-option>
            <el-option key='3' label='普通角色' value='3'></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="en-bullon">
      <el-button size="mini" type="primary" @click="sysRoleSearch" v-if="hasAuth('sys_role_conf_query')">查询</el-button>
      <el-button size="mini" plain type="primary" @click="systemRoleAdd" v-if="hasAuth('sys_role_conf_role_add')">新增</el-button>
      <el-button size="mini" type="primary" plain="plain" @click="clearSearchParam">清除</el-button>
    </div>

    <!-- 查询结果显示 -->
    <div class="en-cnt" v-loading="common.loading">
      <el-table ref="multipleTable" :data="data.list" tooltip-effect="dark" style="width: 100%">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="code" label="角色编码"></el-table-column>
        <el-table-column prop="name" label="角色名称"></el-table-column>
        <el-table-column prop="desc" label="角色描述"></el-table-column>
        <el-table-column prop="type" label="角色类型">
          <template slot-scope="scope">
            <span v-if="scope.row.type == '1'">超级管理员</span>
            <span v-if="scope.row.type == '2'">系统管理员</span>
            <span v-if="scope.row.type == '3'">普通角色</span>
          </template>
        </el-table-column>
        <el-table-column prop="deleted" label="角色类型">
          <template slot-scope="scope">
            <span v-if="scope.row.deleted == '1'">有效</span>
            <span v-if="scope.row.deleted == '0'">无效</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" v-if="hasAuth('sys_role_conf_role_delete') || hasAuth('sys_role_conf_role_menu')">
          <template slot-scope="scope">
            <el-button size="mini" v-if="scope.row.type == '3' && hasAuth('sys_role_conf_role_menu')" @click="editRoleMenu(scope.$index, scope.row)" icon="el-icon-edit" circle title="修改"></el-button>
            <el-button size="mini" v-if="scope.row.type == '3' && hasAuth('sys_role_conf_role_delete')" type="danger" @click="deleteRole(scope.$index, scope.row)" icon="el-icon-delete" circle title="删除"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <footer class="en-footer">
      <el-pagination background layout="total, prev, pager, next" :total="data.total" :pageSize="param.pageSize" @current-change="pageChange" v-if="data.total>0"></el-pagination>
    </footer>

    <el-dialog title="角色修改" :visible.sync="common.sysMenuDailog" width="500px">
      <table style="width:300px;">
        <tr align="right">
          <td style="width:100px;">角色编码：</td>
          <td style="width:200px;"><el-input size="mini" placeholder="角色编码" v-model="edit.row.code" disabled></el-input></td>
        </tr>
        <tr align="right">
          <td>角色名称：</td>
          <td style="width:200px;"><el-input size="mini" placeholder="角色名称" v-model="edit.row.name"></el-input></td>
        </tr>
        <tr align="right">
          <td>角色描述：</td>
          <td><el-input size="mini" placeholder="角色描述" v-model="edit.row.desc"></el-input></td>
        </tr>
      </table>
      <div class="menu_div">
        <el-tree :data="menu.list" show-checkbox node-key="id" :default-expanded-keys="menu.expandId" :default-checked-keys="menu.checked" :props="menu.prop" ref = 'roleMenuTre'></el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="saveRole()" :loading="edit.loading">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="新增角色" :visible.sync="common.addRoleDailog" width="500px">
      <table style="width:300px;">
        <tr align="right">
          <td style="width:100px;">角色编码：</td>
          <td style="width:200px;"><el-input size="mini" placeholder="角色编码" v-model="addRole.code"></el-input></td>
        </tr>
        <tr align="right">
          <td>角色名称：</td>
          <td style="width:200px;"><el-input size="mini" placeholder="角色名称" v-model="addRole.name"></el-input></td>
        </tr>
        <tr align="right">
          <td>角色描述：</td>
          <td><el-input size="mini" placeholder="角色描述" v-model="addRole.desc"></el-input></td>
        </tr>
      </table>
      <div class="menu_div">
        <el-tree :data="menu.list" show-checkbox node-key="id" :default-expanded-keys="menu.expandId" :default-checked-keys="menu.checked" :props="menu.prop" ref = 'addRoleTree'></el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" size="mini" @click="addSystemRole()" :loading="addRole.loading">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>


<script>
  import * as API from '../../api/';
  import CommonUtil from '../../api/utils/common';

  export default {
    data() {
      return {
        common: {
          loading: false,
          sysMenuDailog:false,
          addRoleDailog:false,
          addSystems:[],
          roleAuth:[]
        },
        param: {
          code:'',
          name:'',
          type: '',
          pageNum:1,
          pageSize:10
        },
        data:{
          list:[],
          total:0
        },
        edit:{
          row:{},
          loading:false
        },
        addRole:{
          code:'',
          name:'',
          desc:'',
          loading: false
        },
        menu: {
          list:[],
          expandId:[],
          systemMenu: [],
          checked:[],
          prop:{
            children: 'children',
            label: 'label'
          }
        }
      }
    },
    methods: {
      clearSearchParam:function(){
        this.param = {
          sysId:'',
          roleCode:'',
          roleName:'',
          roleType: '',
          pageNum:1,
          pageSize:10
        }
      },
      sysRoleSearch: function(){
        let that = this
        API.POST('/role/query',that.param).then(result => {
          if (result && result.status == 200) {
            that.data.total = result.total
            that.data.list = result.data
          } else {
            that.data.list = []
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.data.list = []
          that.$message.error({showClose: true, message: err.response.data.message, duration: 2000})
        }).catch(error => {
          that.data.list = []
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      pageChange: function(currentPage) {
        this.param.pageNum = currentPage
        this.sysRoleSearch()
      },
      editRoleMenu: function(index, row){
        let that = this
        that.edit.row.code = row.code
        that.edit.row.name = row.name
        that.edit.row.desc = row.desc
        that.edit.row.id = row.id
        let param ={
          roleId:row.id
        }
        API.GET('/role/roleMenu',param).then(result => {
          if (result && result.status === 200) {
            that.menu.systemMenu = result.data.ids
            that.menu.checked = []
            that.setTreeData(result.data.sysModule.childs)
            that.common.sysMenuDailog = true
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.common.loading = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      setTreeData: function (menu) {
        let that = this
        let result = []
        if(menu != null) {
          for ( let i = 0; i < menu.length; i++){
            result[i] = {}
            let id = menu[i].id
            result[i].id = id
            that.menu.expandId.push(id)
            result[i].label = menu[i].name
            let nextNode = that.setTreeData(menu[i].childs)
            result[i].children = nextNode
            if(nextNode.length <1){
              that.menu.systemMenu.forEach(e => {
                if(e===id){
                  that.menu.checked.push(id)
                }
              })
            }
          }
        }
        that.menu.list = result
        return result
      },
      saveRole: function(){
        let that = this
        const h = this.$createElement;
        that.$confirm('确认修改该角色吗？', '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          that.edit.loading = true
          let ids = []
          that.$refs.roleMenuTre.getCheckedNodes().forEach(node => ids.push(node.id));
          that.$refs.roleMenuTre.getHalfCheckedNodes().forEach(node => ids.push(node.id));
          let param = {
            id:that.edit.row.id,
            name:that.edit.row.name,
            desc:that.edit.row.desc,
            code:that.edit.row.code,
            moduleIds:ids
          }
          API.POST('/role/update',param).then(result => {
            if (result && result.status === 200) {
              that.$message.info({showClose: true, message: '保存成功！', duration: 2000})
              that.common.sysMenuDailog = false
              that.sysRoleSearch()
            } else {
              that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
            that.edit.loading = false
          },err => {
            that.edit.loading = false
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
          }).catch(error => {
            that.edit.loading = false
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
          })
        }).catch(action => {
            
        });
      },
      systemRoleAdd: function(){
        let that = this
        that.addRole.code = ''
        that.addRole.name = ''
        that.addRole.desc = ''
        that.querySysMenu()
      },
      querySysMenu:function(roleId){
        let that = this
        let param ={
          roleId:roleId
        }
        API.GET('/role/roleMenu',param).then(result => {
          if (result && result.status === 200) {
            that.menu.systemMenu = result.data.ids
            that.menu.checked = []
            that.setTreeData(result.data.sysModule.childs)
            that.common.addRoleDailog = true
          } else {
            that.$message.error({showClose: true, message: result.msg, duration: 2000})
          }
        },err => {
          that.common.loading = false
          that.$message.error({showClose: true, message: err.toString(), duration: 2000})
        }).catch(error => {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
        })
      },
      deleteRole: function(index,row){
        const h = this.$createElement;
        this.$confirm(`确认删除[(${row.code})${row.name}]？`, '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          let that = this
          let param = {
            roleId: row.id
          }
          API.GET('/role/delete',param).then(result => {
            if (result && result.status === 200) {
              that.$message.info({showClose: true, message: '删除角色成功！', duration: 2000})
              that.sysRoleSearch()
            } else {
              that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
          },err => {
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
          }).catch(error => {
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
          })
        }).catch(action => {
            
        });
      },
      addSystemRole:function(){
        const h = this.$createElement;
        this.$confirm('确认添加该角色吗？', '确认', {
          distinguishCancelAndClose: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消'
        }).then(() => {
          let that = this
          that.addRole.loading = true
          let ids = []
          that.$refs.addRoleTree.getCheckedNodes().forEach(node => ids.push(node.id));
          that.$refs.addRoleTree.getHalfCheckedNodes().forEach(node => ids.push(node.id));
          let param = {
            code:that.addRole.code,
            name:that.addRole.name,
            desc:that.addRole.desc,
            moduleIds:ids
          }
          API.POST('/role/add',param).then(result => {
            if (result && result.status === 200) {
              that.$message.info({showClose: true, message: '添加角色成功！', duration: 2000})
              that.sysRoleSearch()
              that.common.addRoleDailog = false
            } else {
              that.$message.error({showClose: true, message: result.msg, duration: 2000})
            }
            that.addRole.loading = false
          },err => {
            that.addRole.loading = false
            that.$message.error({showClose: true, message: err.toString(), duration: 2000})
          }).catch(error => {
            that.addRole.loading = false
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000})
          })
        }).catch(action => {
            
        });
      },
      hasAuth(key){
        return CommonUtil.hasAuth('sys_role_conf',key)
      }
    },
    mounted() {
    }
  }
</script>

<style scoped>
.menu_div {
  height: 400px;
  overflow: auto;
}
</style>
