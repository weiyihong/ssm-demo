<template>
  <div class="container">
    <div class="con-head">
      <div class="con-headleft" @click="jumpTo('/')">
        <span>后台管理系统</span>
      </div>
      <div class="con-headmain">
        <div class="head-mainmenu" :title="item.name" v-for="(item,index) in menuList" :key="item.id" @click="changeLeftMenu(index)">{{item.name}}</div>
      </div>
      <div class="con-headright">
        <!-- 右侧角色列表 -->
        <el-cascader size="mini"
          expand-trigger="hover"
          :options="roleList"
          v-model="selectRole"
          @change="roleChange">
        </el-cascader>
        <!-- 右侧个人信息 -->
        <el-dropdown trigger="click">
          <span class="el-dropdown-link con-headtext"><i class="iconfont icon-user"></i> {{userName}}  <i
            class="iconfont icon-down"></i></span>
          <el-dropdown-menu slot="dropdown">
            <!-- <el-dropdown-item>
              <div @click="jumpTo(url.userInfo)"><span style="color: #555;font-size: 14px;">个人信息</span></div>
            </el-dropdown-item>
            <el-dropdown-item>
              <div @click="jumpTo(url.adjPwd)"><span style="color: #555;font-size: 14px;">修改密码</span></div>
            </el-dropdown-item> -->
            <el-dropdown-item divided @click.native="logout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
    <div class="con-main">
      <div class="left-menu" style="collapsed?{width:220px}:{width:55px}">
        <!--展开折叠开关-->
        <div class="left-menuTop" @click.prevent="collapse">
          <i class="iconfont icon-menufold" v-show="!collapsed"></i>
          <i class="iconfont icon-menuunfold" v-show="collapsed"></i>
        </div>
        <div>
          <el-menu default-active="2" class="el-menu-vertical-demo" background-color="#545c64" text-color="#fff" active-text-color="#ffd04b" :collapse="collapsed" @select="handleSelect">
            <el-submenu v-for="(menu,index) in leftMenus" :index="menu.code" :key="index">
              <template slot="title">
                <i :class="menu.icon"></i>
                <span slot="title">{{menu.name}}</span>
              </template>
                <el-menu-item v-for="(child,cindex) in menu.childs" :index="child.url" :key="cindex">{{child.name}}</el-menu-item>
            </el-submenu>
          </el-menu>
        </div>
      </div>
      <div class="main-content">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
  import {bus} from '../bus.js'
  import * as API from '../api/'
  import STORE from '../api/local_store'

  export default {
    name: 'home',
    created(){
      bus.$on('setUserName', (text) => {
        this.userName = text;
      })

      bus.$on('goto', (url) => {
        if (url === "/login") {
          STORE.remove()
        }
        this.$router.push(url);
      })
    },
    data () {
      return {
        url:{
          adjPwd: '',
          userInfo: ''
        },
        defaultActiveIndex: "0",
        userName: '',
        collapsed: false,
        roleList:[],
        roleIdType: {},
        selectRole:[],
        menuList:[],
        leftMenus:[]
      }
    },
    methods: {
      /**
       * 获取角色信息
       */
      getRole(){
        let that = this
        API.GET('/role/getRole').then(function (result) {
          if (result && result.status == 200) {
            that.jumpTo('/')
            that.setRoleList(result.data)
            that.getRuleAuth()
            that.getMenus()
            that.getDeptCodes()
          } else {
            that.$message.error({showClose: true, message: result.msg || '获取角色信息失败！', duration: 2000});
          }
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      getDeptCodes(){
        let that = this
        API.GET('/common/userDept').then(function (result) {
          if (result && result.status == 200) {
           STORE.setDeptCodes(result.data)
          } else {
            that.$message.error({showClose: true, message: result.msg || '获取角色权限信息失败！', duration: 2000});
          }
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      getRuleAuth(){
        let that = this
        API.GET('/role/getRoleAuth').then(function (result) {
          if (result && result.status == 200) {
            STORE.setRoleAuth(result.data)
          } else {
            that.$message.error({showClose: true, message: result.msg || '获取角色权限信息失败！', duration: 2000});
          }
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      /**
       * 退出登录
       */
      logout(){
        let that = this;
        this.$confirm('确认退出吗?', '提示', {
          confirmButtonClass: 'el-button--warning'
        }).then(() => {
          //确认
          API.GET('/user/logOut').then(function (result) {
            if (result && result.status == 200) {
              that.$router.push({path: '/login'});
            } else {
              that.$message.error({showClose: true, message: result.msg || '退出登录失败！', duration: 2000});
            }
          }, function (err) {
            that.$message.error({showClose: true, message: err.toString(), duration: 2000});
          }).catch(function (error) {
            that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
          });
        }).catch(() => {});
      },
      /**
       * 设置角色信息
       */
      setRoleList(roleList){
        let roleShow = [];
        if(roleList != null){
          for(let i in roleList) {
            let system = roleList[i]
            roleShow[i] = {}
            roleShow[i].label = system.sysName
            roleShow[i].value = system.id
            
            let sysRole = []
            for(let j in system.roleList){
              let role = system.roleList[j]

              if(role.isDefault && role.isDefault === 1){
                this.selectRole[0] = system.id
                this.selectRole[1] = role.id
                // STORE.setRoleType(role.type)
              }

              sysRole[j] = {}
              sysRole[j].label = role.name
              sysRole[j].value = role.id
              this.roleIdType[role.id] = role.type
            }
            roleShow[i].children = sysRole
          }
        }
        this.roleList = roleShow
      },
      /**
       * 设置用户信息
       */
      setUser(){
        let user = STORE.getUser()
        if (user != null) {
          this.userName = user.name || '';
        } else {
          this.$router.go('/login'); //用go刷新
        }
      },
      /**
       * 角色切换
       */
      roleChange(value){
        let that = this;
        let param = {
          roleId:this.selectRole[1]
        }
        API.GET('/role/changeRole',param).then(result => {
          if (result && result.status == 200) {
            that.jumpTo('/')
            STORE.setRoleAuth(result.data)
            that.getMenus()
            that.getDeptCodes()
          } else {
            if(result && result.msg == 'refreash') {
              that.$router.go('/'); //用go刷新
            } else {
              that.$message.error({showClose: true, message: '您未进行角色切换！', duration: 2000});
            }
          }
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        })
      },
      /**
       * 获取菜单信息
       */
      getMenus(){
        let that = this
        API.GET('/module/getMenu').then(function (result) {
          if (result && result.status == 200) {
            if(result.data.childs == null) {
              that.menuList = []
              that.leftMenus = []
              that.$message.error({showClose: true, message: '该角色没有相关的系统菜单信息！', duration: 2000});
            } else {
              that.setMenus(result.data)
            }
          } else {
            that.$message.error({showClose: true, message: result.msg || '退出登录失败！', duration: 2000});
          }
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        })
      },
      /**
       * 设置系统菜单
       */
      setMenus(menu){
        this.menuList = menu.childs
        this.leftMenus = menu.childs[0].childs
      },
      /**
       * 切换左侧菜单
       */
      changeLeftMenu(index){
        this.leftMenus = this.menuList[index].childs
        this.jumpTo('/')
      },
      /**
       * 页面跳转
       */
      handleSelect(index){
        this.defaultActiveIndex = index;
        this.jumpTo(index)
      },

      
      
      initUrl(){
        this.url.adjPwd = '/index/adjPwd'
        this.url.userInfo = '/index/userInfo'
      },
      
      //折叠导航栏
      collapse: function () {
        this.collapsed = !this.collapsed;
      },
      jumpTo(url){
        this.defaultActiveIndex = url;
        this.$router.push(url); //用go刷新
      }
    },
    mounted() {
      // 获取角色信息
      this.getRole()
      // 设置用户信息
      this.setUser()
      /*
      // 初始化url
      this.initUrl()
      */
    }
  }
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  .container {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    .con-head {
      height: 50px;
      line-height: 50px;
      display: flex;
      flex-direction: row;
      flex-wrap:nowrap;
      background-color: #545c64;
      color: #fff;
      font-size: 25px;

      .con-headleft {
        width: 220px;
        justify-content: center;
        display: flex;
        align-items: center;
        cursor: pointer;
      }
      .con-headmain {
        flex:1;
        display: flex;

        .head-mainmenu {
          padding: 0px 30px;
          font-size: 20px;
          cursor: pointer;
        }
      }
      .con-headright {
        width: 280px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        justify-content: space-between;
        padding: 0px 5px;

        .con-headtext {
          color: #fff;
        }
      }
    }
    .con-main {
      flex: 1;
      display: flex;

      .left-menu {
        //width: 65px;
        background-color: #545c64;

        .left-menuTop{
          height: 30px;
          min-width: 65px;
          display: flex;
          justify-content: center;
          line-height: 30px;
          color: #fff;
        }
      }

      .main-content {
        flex: 1;
        overflow: auto;
        display: flex;
        background-color: #f0f0f4;
      }
    }
  }

</style>
