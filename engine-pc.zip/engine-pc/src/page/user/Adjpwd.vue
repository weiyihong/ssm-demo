<template>
  <div class="en-container">
    <div class="en-title">
      修改密码
    </div>

    <div class="en-cnt">
      <el-form ref="form" :model="form" :rules="rules" label-width="120px" style="width:500px;">
        <el-form-item prop="oldPwd" label="原密码">
          <el-input type="password" v-model="form.oldPwd"></el-input>
        </el-form-item>
        <el-form-item prop="newPwd" label="新密码">
          <el-input type="password" v-model="form.newPwd"></el-input>
        </el-form-item>
        <el-form-item prop="confirmPwd" label="确认新密码">
          <el-input type="password" v-model="form.confirmPwd"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleChangepwd">提交</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import * as API from '../../api/';
export default{
  data(){
    return {
      form: {
        oldPwd: '',
        newPwd: '',
        confirmPwd: ''
      },
      rules: {
        oldPwd: [
          {required: true, message: '请输入原密码', trigger: 'blur'}
        ],
        newPwd: [
          {required: true, message: '请输入新密码', trigger: 'blur'}
        ],
        confirmPwd: [
          {required: true, message: '请请确认新密码', trigger: 'blur'}
        ]
      }
    }
  },
  methods: {
    handleChangepwd() {
      let that = this
      that.$refs.form.validate(valid => {
        if(valid) {
          let old = that.form.oldPwd
          let newPwd = that.form.newPwd
          if(newPwd != that.form.confirmPwd) {
            this.$message({message: '两次输入的密码必须一致！', duration: 2000});
            return
          }
          this.$confirm(`确认修改？`, '确认', {
            distinguishCancelAndClose: true,
            confirmButtonText: '确定',
            cancelButtonText: '取消'
          }).then(() => {
            let param = {
              oldPwd:old,
              newPwd:newPwd
            }
            API.POST('/user/updatePwd',param).then(result =>{
              if (result && result.status === 200) {
                //修改成功
                that.$message.success({showClose: true, message: '密码修改成功！', duration: 2000});
                that.$router.push('/');
              } else {
                that.$message.error({showClose: true, message: result.msg, duration: 2000});
              }
            },err =>{
              that.$message.error({showClose: true, message: err.toString(), duration: 2000});
            }).catch(error => {
              that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
            })
          }).catch(action => {
            
          });
            
        }
      })
    }
  }
}
</script>
