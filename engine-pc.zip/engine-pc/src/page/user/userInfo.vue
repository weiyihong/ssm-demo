<template>
  <div class="en-container">
    <div class="en-title">
      个人信息
    </div>

    <div class="en-cnt">
      <el-form ref="form" :model="form" :rules="rules" label-width="80px"  style="width:500px;">
        <el-form-item label="账号">
          <el-input v-model="form.code" disabled></el-input>
        </el-form-item>
        <el-form-item prop="name" label="名称">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item prop="sex" label="性别">
          <el-radio v-model="form.sex" label="0">男</el-radio>
          <el-radio v-model="form.sex" label="1">女</el-radio>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSaveProfile">修改并保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import * as API from '../../api/';
import {bus} from '../../bus.js'
import STORE from '../../api/local_store';
import local_store from '../../api/local_store';
export default {
  data() {
    return {
      loading: false,
      form: {
        code: '',
        name: '',
        sex: ''
      },
      rules: {
        name: [
          {required: true, message: '请输入名称', trigger: 'blur'}
        ],
        sex: [
          {required: true, message: '请选择性别', trigger: 'blur'}
        ]
      },
    }
  },
  methods: {
    handleSaveProfile() {
      let that = this;
      that.$refs.form.validate((valid) => {
        if (valid) {
          that.loading = true;
          let args = {
            code: that.form.code,
            name: that.form.name,
            sex: that.form.sex
          };
          this.$confirm(`确认修改？`, '确认', {
            distinguishCancelAndClose: true,
            confirmButtonText: '确定',
            cancelButtonText: '取消'
          }).then(() => {
            API.POST('/user/updateInfo',args).then(function (result) {
              that.loading = false;
              if (result && result.status === 200) {
                //修改成功
                let user = STORE.getUser();
                user.code = that.form.code;
                user.name = that.form.name;
                user.sex = that.form.sex;
                STORE.setUser(user)
                bus.$emit('setUserName', that.form.name);
                that.$message.success({showClose: true, message: '修改成功', duration: 2000});
                that.$router.push({path: '/'});
              } else {
                that.$message.error({showClose: true, message: result.msg, duration: 2000});
              }
            }, function (err) {
              that.loading = false;
              that.$message.error({showClose: true, message: err.toString(), duration: 2000});
            }).catch(function (error) {
              that.loading = false;
              that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
            });
          }).catch(action => {
            
          });
        }
      });
    }
  },
  mounted() {
    let user = STORE.getUser()
    if (user != null) {
      this.form.code = user.code;
      this.form.name = user.name || '';
      this.form.sex = user.sex || '';
    }
  }
}

</script>
