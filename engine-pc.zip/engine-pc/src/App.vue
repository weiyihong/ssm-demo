<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang='scss'>
* {
  margin: 0;
  padding: 0;
}
a {
  text-decoration:none;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  display: flex;
}

html, body, #app{
  min-width: 1200px;
  width: 100%;
  height: 100%;
  min-width: 980px;
  min-height: 500px;
  background-color: #fff;
  overflow: auto;
}

/**系统顶部样式**/ 
/**.topHeader {
  width: calc(100% - 220px);
  height: 60px;
  position: absolute;
  top: 0;
  left: 0;
  margin-left: 220px;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  background-color: #252834;
}
/**项目目录区域**/
/*.navBar{
  ul {
    display: flex;
    justify-content: flex-start;
    margin-left: 67px;
    border: 0;
  }
  li {
    width: 184px;
    font-size: 16px;
    color: #989898;
    line-height: 58px;
    text-align: center;
  }
}
/**右侧内容**/
/*.rightMainBody{
  width: 100%;
  height: 100%;
  padding-top: 60px;
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: space-between;
  overflow: hidden;
  overflow-y: auto;
  .viewStyle{
    width: 100%;
    height: 100%;
    padding: 0px 15px 15px 15px;
  }
}*/
.en-container {
  width: 100%;
  background-color: #fff;
  border-radius: 10px;
  margin: 10px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  box-shadow: 5px 5px 5px rgba(0,0,0,.3);

  .en-title {
    margin: 0px;
    padding: 5px 10px;
    background-color: #f0f0f4;
    height: 30px;
    font-size: 0.8em;
    line-height: 30px;
    
    .en_button{
      float: right;
      margin-right: 20px;
    }
  }

  .en-search{
    margin: 15px 5px 0px 5px;
    padding: 0px 10px;
    border-radius: 10px;
  }
  .en-bullon{
    padding: 5px 20px;
    background-color: #f0f0f4;
  }
  .en-cnt{
    margin: 10px;
    padding: 5px 10px;
    flex:1;
    overflow: auto;
  }
  .en-footer{
    margin: 10px;
    padding: 5px 10px;
    border-radius: 10px;
    border:1px dotted #ccc;
    height: 30px;
    line-height: 30px;
  }
  .el-dialog__close {
    margin: 0px;
    position: absolute;
    right: 0px;
    top: -5px;
  }
  .el-dialog__header {
    padding: 10px;
    // border-bottom: 2px inset #f0f0f4;
    background-color: rgba(233,241,246,0.8);
    margin-bottom: 10px;
  }
  .el-dialog__body {
    padding: 0px 30px;

    .el-upload-dragger{
      background-color: #f0f0f4;
      line-height: 180px;
      border: #fff dotted 5px;
      border-radius: 55px;
      width: 430px;
      margin: 30px;

      :hover {
        background-color: rgba(232,194,187,0.3);
      }
    }
  }
  .el-dialog__footer{
    background-color: rgba(240,240,244,0.5);
    // border-top: 1px dashed #a1afc9;
    padding: 10px 30px;
  }
}

  .modify-table{
    background: #f0f0f4;
    margin: 0px;
    padding: 0px;
    width: 100%;
    th {
      background-color: #555;
      color: #fff;
      line-height: 30px;
      text-align: center;
      width:50%;
    }
    td {
      text-align: center;
      line-height: 30px;
    }
  }

</style>
